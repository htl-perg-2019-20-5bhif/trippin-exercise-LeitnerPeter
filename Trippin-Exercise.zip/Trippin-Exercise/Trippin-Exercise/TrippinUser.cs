﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json.Serialization;

namespace Trippin_Exercise
{
    public class Trippin_User
    {        
        [JsonPropertyName("UserName")]
        public string Username { get; set; }

        [JsonPropertyName("FirstName")]
        public string Firstname { get; set; }

        [JsonPropertyName("LastName")]
        public string Lastname { get; set; }

        [JsonPropertyName("Emails")]
        public IEnumerable<string> Emails { get; set; }

        [JsonPropertyName("AddressInfo")]
        public IEnumerable<AddressInfo> AddressInfo { get; set; }


        public Trippin_User(User user)
        {
            this.Username = user.Username;
            this.Firstname = user.FirstName;
            this.Lastname = user.LastName;
            this.Emails = new string[] { user.Email };
            AddressInfo addressInfo = new AddressInfo(user);
            this.AddressInfo = new AddressInfo[] { addressInfo };
        }
        
    }
}
