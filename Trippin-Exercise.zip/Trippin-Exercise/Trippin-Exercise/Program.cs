﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Trippin_Exercise
{
    class Program
    {
        private IEnumerable<User> users;

        static async Task Main(string[] args)
        {
            Program p = new Program();
            await p.readFile("users.json");
             p.check();

        }

        public async Task<IEnumerable<User>> readFile(string filename)
        {
            users = new List<User>();
            users = (JsonSerializer.Deserialize<IEnumerable<User>>(await File.ReadAllTextAsync(filename)));
            return users;
        }
        public async void check()
        {
         HttpClient HttpClient = new HttpClient() { BaseAddress = new Uri("https://services.odata.org/TripPinRESTierService/People/") };
            foreach(var user in users)
            {
                var result = await HttpClient.GetAsync("People('" + user.Username + "')");
                if (result.IsSuccessStatusCode)
                {
                    Console.WriteLine("User existiert bereits");
                } else
                {
                    Trippin_User trippinUser = new Trippin_User(user);
                    var content = new StringContent(JsonSerializer.Serialize(trippinUser), Encoding.UTF8, "application/json");
                    var newUser = await HttpClient.PostAsync("People", content);
                }
            }

        }        
    }
}
